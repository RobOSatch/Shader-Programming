#pragma once
class Timer
{
public:
	Timer();
	~Timer();

	static void start();
	static void stop();
};

